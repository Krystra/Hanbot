return {
  id = 'Kloader',
  name = "Krystra's Loader",
  load = function()
    return true
  end,
}